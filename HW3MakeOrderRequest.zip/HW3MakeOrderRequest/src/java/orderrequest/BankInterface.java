
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orderrequest;

/**
 *
 * @author Lauren
 */



public class BankInterface {
   
    public void authorize(String cardNo){
        //because writing logic for the bank was not part of this assignment, I used bank.jsp and bankprocess.jsp to simulate bank interface/logic 
    
    } 
}
